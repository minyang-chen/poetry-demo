def dots_to_underscores(s):
    return s.replace(".", "_", 1)

